//
//  MailVC.swift
//  CCET
//
//  Created by MAC on 27/08/17.
//  Copyright © 2017 MAC. All rights reserved.
//

import UIKit
import MessageUI
import QuartzCore

class MailVC: UIViewController , MFMailComposeViewControllerDelegate ,CAAnimationDelegate {
    @IBOutlet weak var feedbackO: UIButton!
    
    @IBOutlet weak var lbl3: UILabel!
    @IBOutlet weak var lbl2: UILabel!
    @IBOutlet weak var lbl1: UILabel!
    @IBOutlet weak var supportO: UIButton!
    @IBOutlet weak var queryO: UIButton!
    var mask: CALayer?
    @IBOutlet var imgV: UIImageView!
    @IBAction func QUERY(_ sender: Any) {
        mail()
    }
    @IBAction func support(_ sender: Any) {
        mail()
    }
    @IBAction func feedback(_ sender: Any) {
        //mail()
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.mask = CALayer()
        self.mask!.contents = UIImage(named: "mail-black-envelope-symbol")!.cgImage
        self.mask!.contentsGravity = kCAGravityResizeAspect
        self.mask!.bounds = CGRect(x: 0, y: 0, width: 100, height: 100)
        self.mask!.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        self.mask!.position = CGPoint(x: view.frame.size.width/2, y: view.frame.size.height/2)
        
        imgV.layer.mask = mask
        //self.mapPage.alpha = 0
        
        self.view.backgroundColor = UIColor(red: 121/255.0, green: 77/255.0, blue: 202/255.0, alpha: 1)
        
        animate()

        //mail()

        // Do any additional setup after loading the view.
    }
    
    func animate() {
        
        let keyFrameAnimation = CAKeyframeAnimation(keyPath: "bounds")
        keyFrameAnimation.delegate = self
        keyFrameAnimation.duration = 1
        keyFrameAnimation.beginTime = CACurrentMediaTime() + 0.5
        
        //start
        let initialBounds = NSValue(cgRect:mask!.bounds)
        
        let middleBounds = CGRect(x: 0, y: 0, width: 90, height: 90)
        
        let finalBounds = CGRect(x: 0, y: 0, width: 900, height: 900)
        
        
        keyFrameAnimation.values = [initialBounds,middleBounds,finalBounds]
        keyFrameAnimation.keyTimes = [0,0.3,1]
        keyFrameAnimation.timingFunctions = [CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut),(CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseOut))]
        
        //add animation
        
        self.mask?.add(keyFrameAnimation,forKey: "bounds")
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func animationDidStop(_ anim: CAAnimation, finished flag: Bool) {
        
        self.imgV.alpha = 0

            self.queryO.isHidden = false
            self.feedbackO.isHidden = false
            self.supportO.isHidden = false
            self.lbl1.isHidden = false
            self.lbl2.isHidden = false
            self.lbl3.isHidden = false
    
        
        
        
        UIView.animate(withDuration: 0.8) {
            self.imgV.layer.mask = nil
            //self.imgV.alpha = 0
            
            self.view.backgroundColor = UIColor(red: 255/255.0, green: 255/255.0, blue: 255/255.0, alpha: 1)

        }
        

        
    }


    
    func mail() {
        let mailComposeViewController = configureMailController()
        if MFMailComposeViewController.canSendMail() {
            self.present(mailComposeViewController, animated: true, completion: nil)
        } else {
            showMailError()
        }
    }
    
    func configureMailController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        
        mailComposerVC.setToRecipients(["madhurdeep29@gmail.com"])
        mailComposerVC.setSubject("Hello")
        mailComposerVC.setMessageBody("How are you doing?", isHTML: false)
        
        return mailComposerVC
    }
    
    func showMailError() {
        let sendMailErrorAlert = UIAlertController(title: "Could not send email", message: "Your device could not send email", preferredStyle: .alert)
        let dismiss = UIAlertAction(title: "Ok", style: .default, handler: nil)
        sendMailErrorAlert.addAction(dismiss)
        self.present(sendMailErrorAlert, animated: true, completion: nil)
    }
    
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith result: MFMailComposeResult, error: Error?) {
        controller.dismiss(animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
