//
//  TableViewCell2.swift
//  CCET
//
//  Created by Ravjot kaur on 18/01/18.
//  Copyright © 2018 MAC. All rights reserved.
//

import UIKit

class TableViewCell2: UITableViewCell {
    
   // @IBOutlet weak var myImage: UIImageView!

    @IBOutlet weak var imgg: UIImageView!
    
    @IBOutlet weak var textt: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
