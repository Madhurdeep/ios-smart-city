//
//  ViewController.swift
//  CCET
//
//  Created by MAC on 11/08/17.
//  Copyright © 2017 MAC. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    @IBOutlet weak var contact: UILabel!
    
    @IBOutlet weak var backdrop: UIImageView!
    @IBOutlet weak var add: UILabel!
    
    @IBOutlet weak var five: UIButton!
    @IBOutlet weak var fout: UIButton!
    @IBOutlet weak var three: UIButton!
    @IBOutlet weak var two: UIButton!
    @IBOutlet weak var one: UIButton!
    @IBOutlet weak var back: UIImageView!
    @IBOutlet weak var line1: UIImageView!
    @IBOutlet weak var line2: UIImageView!
    @IBOutlet weak var notices: UIButton!
    @IBOutlet weak var students: UIButton!
    @IBOutlet weak var events: UIButton!
    @IBOutlet weak var nameback: UIImageView!
    @IBOutlet weak var tp: UIButton!
    @IBOutlet weak var menuButton: UIButton!
    @IBOutlet weak var about: UIButton!
    @IBOutlet weak var ccet_logo: UIImageView!

    override func viewDidLoad() {
        super.viewDidLoad()
   
        self.backdrop.alpha = 1
        
        UIView.animate(withDuration: 1) {
            self.backdrop.alpha = 0
        }

        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    

    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
       // line1.alpha = 0
       // line2.alpha = 0
        notices.alpha = 0
        students.alpha = 0
        events.alpha = 0
        tp.alpha = 0
        menuButton.alpha = 0
        about.alpha = 0
        //name_lbl.alpha = 0
        ccet_logo.alpha = 0
        
       // back.alpha = 0
        
        //one.alpha = 0
       // two.alpha = 0
        three.alpha = 0
        fout.alpha = 0
        five.alpha = 0
        //contact.alpha = 0
       // add.alpha = 0
        //nameback.alpha = 0
        backdrop.alpha = 1
        

        
        UIView.animate(withDuration: 0.2, animations: {
            
            //self.name_lbl.alpha = 1
            //self.nameback.alpha = 1
            self.ccet_logo.alpha = 1
            //self.line1.alpha = 1
            //self.line2.alpha = 1
            
        }) { (true) in
            UIView.animate(withDuration: 0.5, animations: {
                self.about.alpha = 1
                self.tp.alpha = 1
                self.students.alpha = 1
                self.events.alpha = 1
                self.notices.alpha = 1
                self.menuButton.alpha = 1
                //self.ccet_logo.alpha = 0.5
               // self.back.alpha = 1
                
            },  completion: { (true) in
                
                    UIView.animate(withDuration: 0.5, animations: {
                        //self.add.alpha = 1
                        //self.ccet_logo.alpha = 1
                        //self.one.alpha = 1
                        //self.two.alpha = 1
                        self.three.alpha = 1
                        self.fout.alpha = 1
                        self.five.alpha = 1
                      //  self.contact.alpha = 1
                    })

                })
        }
    }

    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    

    


}

