//
//  aboutVC.swift
//  CCET
//
//  Created by MAC on 14/08/17.
//  Copyright © 2017 MAC. All rights reserved.
//

import UIKit
import QuartzCore

class aboutVC: UIViewController ,CAAnimationDelegate, UITableViewDataSource,UITableViewDelegate{
    
    var mask: CALayer?
    

    @IBOutlet weak var TV: UITableView!
    
    
    var names = [String]()
    var identities = [String]()
    
    let imgs = [ "Dr. Manpreet Singh Gujral - Professor"]
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        names = ["JW Marriot"]
        identities = ["AA"]
        
        TV.dataSource = self
        TV.delegate = self
        
        // Do any additional setup after loading the view.
        
   /*     self.mask = CALayer()
        self.mask!.contents = UIImage(named: "ABTF")!.cgImage
        self.mask!.contentsGravity = kCAGravityResizeAspect
        self.mask!.bounds = CGRect(x: 0, y: 0, width: 100, height: 100)
        self.mask!.anchorPoint = CGPoint(x: 0.5, y: 0.5)
        self.mask!.position = CGPoint(x: view.frame.size.width/2, y: view.frame.size.height/2)
        
      //imgV.layer.mask = mask
        //self.mapPage.alpha = 0
        
        self.view.backgroundColor = UIColor(red: 57/255.0, green: 89/255.0, blue: 54/255.0, alpha: 1)
        
        animate()*/
        
        
        


        
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = TV.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCell
        
        cell.myImage.image = UIImage(named: (imgs[indexPath.row] + ".JPG"))
        cell.myLabel.text = names[indexPath.row]
        
        return (cell)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return names.count
    }
    
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        //set inittial state
        cell.alpha = 0
        let transform = CATransform3DTranslate(CATransform3DIdentity, -250, 30, 0)
        
        cell.layer.transform = transform
        
        
        // animating to final state
        
        UIView.animate(withDuration: 1) {
            cell.alpha = 1
            cell.layer.transform = CATransform3DIdentity
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vcname = identities[indexPath.row]
        let viewcontroller = storyboard?.instantiateViewController(withIdentifier: vcname)
        self.navigationController?.pushViewController(viewcontroller!, animated: true)
    }
    
    
    
    
    func animate() {
        
        let keyFrameAnimation = CAKeyframeAnimation(keyPath: "bounds")
        keyFrameAnimation.delegate = self
        keyFrameAnimation.duration = 1
        keyFrameAnimation.beginTime = CACurrentMediaTime() + 0.5
        
        //start
        let initialBounds = NSValue(cgRect:mask!.bounds)
        
        let middleBounds = CGRect(x: 0, y: 0, width: 90, height: 90)
        
        let finalBounds = CGRect(x: 0, y: 0, width: 900, height: 900)
        
        
        keyFrameAnimation.values = [initialBounds,middleBounds,finalBounds]
        keyFrameAnimation.keyTimes = [0,0.3,1]
        keyFrameAnimation.timingFunctions = [CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut),(CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseOut))]
        
        //add animation
        
        self.mask?.add(keyFrameAnimation,forKey: "bounds")
        
        
    }
    
    
    func animationDidStop(_ anim: CAAnimation, finished flag: Bool) {
        
        //self.imgV.alpha = 0
      //  self.imgV.layer.mask = nil
        
        
        
        
        
        
        //UIView.animate(withDuration: 0.8) {
        
            //self.imgV.alpha = 0
            
            //self.view.backgroundColor = UIColor(red: 255/255.0, green: 255/255.0, blue: 255/255.0, alpha: 1)
            
       // }
   
    }


    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}

