//
//  locationVC.swift
//  CCET
//
//  Created by MAC on 27/08/17.
//  Copyright © 2017 MAC. All rights reserved.
//

import UIKit
import QuartzCore
import MapKit
import CoreLocation

class locationVC: UIViewController , CAAnimationDelegate , MKMapViewDelegate, CLLocationManagerDelegate, UITextFieldDelegate{
    
    @IBOutlet weak var webkit: UIWebView!
    var mask: CALayer?
        @IBOutlet weak var mapPage: MKMapView!
        @IBOutlet var imgV: UIImageView!
        var key = ""
        var key1 = ""

    override func viewWillAppear(_ animated: Bool) {
        
        self.navigationController?.setNavigationBarHidden(false, animated: true)
        
        getkey0()
        getkey1()
        print(key1)
        print(key)
        
        
        if(key == "0")
        {
            if(key1 == "4")
            {
                webkit.isHidden = true
                
                
                
                self.mask = CALayer()
                self.mask!.contents = UIImage(named: "facebook-placeholder-for-locate-places-on-maps-4")!.cgImage
                self.mask!.contentsGravity = kCAGravityResizeAspect
                self.mask!.bounds = CGRect(x: 0, y: 0, width: 100, height: 100)
                self.mask!.anchorPoint = CGPoint(x: 0.5, y: 0.5)
                self.mask!.position = CGPoint(x: view.frame.size.width/2, y: view.frame.size.height/2)
                
                imgV.layer.mask = mask
                self.mapPage.alpha = 0
                
                self.view.backgroundColor = UIColor(red: 121/255.0, green: 77/255.0, blue: 202/255.0, alpha: 1)
                
                animate()
                
                map()
            }
            if(key1 == "2")
            {
                 //webkit.isHidden = true
                let url = URL (string: "https://www.marriott.com/hotels/travel/ixcjw-jw-marriott-hotel-chandigarh/")
                let requestObj = URLRequest(url: url!)
                webkit.loadRequest(requestObj)
                
                
            }
            if(key1 == "1")
            {
                //webkit.isHidden = true
                let url = URL (string: "https://goo.gl/forms/MqxODoCoSpj6Ldb32")
                let requestObj = URLRequest(url: url!)
                webkit.loadRequest(requestObj)
                
                
            }
            
            if ( key1 == "3")
            {
                let instagramUrl = URL(string: "uber://app")
                UIApplication.shared.canOpenURL(instagramUrl!)
                UIApplication.shared.open(instagramUrl!, options: [:], completionHandler: nil)
            }
            if(key1 == "5")
            {
                if let url = URL(string: "tel://\(01723955555)"), UIApplication.shared.canOpenURL(url) {
                    if #available(iOS 10, *) {
                        UIApplication.shared.open(url)
                    } else {
                        UIApplication.shared.openURL(url)
                    }
                }
            }
            
        }
        else if(key == "1")
        {
            if(key1 == "4")
            {
                webkit.isHidden = true
                
                self.mask = CALayer()
                self.mask!.contents = UIImage(named: "facebook-placeholder-for-locate-places-on-maps-4")!.cgImage
                self.mask!.contentsGravity = kCAGravityResizeAspect
                self.mask!.bounds = CGRect(x: 0, y: 0, width: 100, height: 100)
                self.mask!.anchorPoint = CGPoint(x: 0.5, y: 0.5)
                self.mask!.position = CGPoint(x: view.frame.size.width/2, y: view.frame.size.height/2)
                
                imgV.layer.mask = mask
                self.mapPage.alpha = 0
                
                self.view.backgroundColor = UIColor(red: 121/255.0, green: 77/255.0, blue: 202/255.0, alpha: 1)
                
                animate()
                
                map()
            }
            if(key1 == "1")
            {
                //webkit.isHidden = true
                let url = URL (string: "https://goo.gl/forms/MqxODoCoSpj6Ldb32")
                let requestObj = URLRequest(url: url!)
                webkit.loadRequest(requestObj)
                
                
            }
            if(key1 == "2")
            {
                
               // webkit.isHidden = true
                let url = URL (string: "https://www.makemytrip.com/hotels/hotel_aroma_classic-details-chandigarh.html")
                let requestObj = URLRequest(url: url!)
                webkit.loadRequest(requestObj)
            }
            if(key1 == "5")
            {
                if let url = URL(string: "tel://\(01724010027)"), UIApplication.shared.canOpenURL(url) {
                    if #available(iOS 10, *) {
                        UIApplication.shared.open(url)
                    } else {
                        UIApplication.shared.openURL(url)
                    }
                }
            }
            if ( key1 == "3")
            {
                let instagramUrl = URL(string: "uber://app")
                UIApplication.shared.canOpenURL(instagramUrl!)
                UIApplication.shared.open(instagramUrl!, options: [:], completionHandler: nil)
            }
            
        }
        else
        {
            print("not found")
        }

    }
        override func viewDidLoad() {
        super.viewDidLoad()
        
        
        // Do any additional setup after loading the view.
    }
    
    func getkey0()
    {
        
        let defaults = UserDefaults.standard
        let token = defaults.string(forKey: "Key0")
        self.key = token!
        
    }
    
    func getkey1()
    {
        
        let defaults = UserDefaults.standard
        let token = defaults.string(forKey: "Key1")
        self.key1 = token!
        
    }
    
    func map() {
        
        if(key == "1")
        {

        let location = CLLocationCoordinate2DMake(30.730041,76.773548)
        
        let span = MKCoordinateSpanMake(0.02, 0.02)
        
        let region = MKCoordinateRegionMake(location, span)
            
        let annotation = MKPointAnnotation()
        //annotation.setCoordinate(location)
        annotation.coordinate = location
        annotation.title = "Aroma Hotel"
        annotation.subtitle = "Sector-22,Chd"
            
            UIView.animate(withDuration: 4) {
                self.mapPage.alpha = 1
                
            }
            
            mapPage.setRegion(region, animated: true)
            
            
            mapPage.addAnnotation(annotation)
            
            //Showing the device location on the map
            self.mapPage.showsUserLocation = true;
            
        }
        else if(key == "0")
        {
            
            let location = CLLocationCoordinate2DMake(30.726705,76.767135)
            
            let span = MKCoordinateSpanMake(0.02, 0.02)
            
            let region = MKCoordinateRegionMake(location, span)
            
            let annotation = MKPointAnnotation()
            //annotation.setCoordinate(location)
            annotation.coordinate = location
            annotation.title = "J W Marriot"
            annotation.subtitle = "Sector-35,Chd"
            
            UIView.animate(withDuration: 4) {
                self.mapPage.alpha = 1
                
            }
            
            mapPage.setRegion(region, animated: true)
            
            
            mapPage.addAnnotation(annotation)
            
            //Showing the device location on the map
            self.mapPage.showsUserLocation = true;
            
        }
        
        
       
        
    }
    func animate() {
        
        let keyFrameAnimation = CAKeyframeAnimation(keyPath: "bounds")
        keyFrameAnimation.delegate = self
        keyFrameAnimation.duration = 1
        keyFrameAnimation.beginTime = CACurrentMediaTime() + 0.5
        
        //start
        let initialBounds = NSValue(cgRect:mask!.bounds)
        
        let middleBounds = CGRect(x: 0, y: 0, width: 90, height: 90)
        
        let finalBounds = CGRect(x: 0, y: 0, width: 900, height: 900)
        
        
        keyFrameAnimation.values = [initialBounds,middleBounds,finalBounds]
        keyFrameAnimation.keyTimes = [0,0.3,1]
        keyFrameAnimation.timingFunctions = [CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseInEaseOut),(CAMediaTimingFunction(name: kCAMediaTimingFunctionEaseOut))]
        
        //add animation
        
        self.mask?.add(keyFrameAnimation,forKey: "bounds")
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func animationDidStop(_ anim: CAAnimation, finished flag: Bool) {
        
        self.imgV.alpha = 0
        UIView.animate(withDuration: 0.8) {
        self.imgV.layer.mask = nil
        }
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
