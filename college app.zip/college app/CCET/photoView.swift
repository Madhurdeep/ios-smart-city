//
//  photoView.swift
//  CCET
//
//  Created by MAC on 31/08/17.
//  Copyright © 2017 MAC. All rights reserved.
//

import UIKit

@IBDesignable class photoView: UIView {

    var cornerRad : CGFloat = 0 {
        didSet {
            self.layer.cornerRadius = cornerRad
    }

   }
    
}
