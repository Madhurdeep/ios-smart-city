//
//  cseTVC.swift
//  CCET
//
//  Created by MAC on 22/08/17.
//  Copyright © 2017 MAC. All rights reserved.
//

import UIKit


class cseTVC: UITableViewController {
    

    
    
    
    var names = [String]()
    var identities = [String]()
    
    let imgs = [ "cse_table" ,"cse_table" ,"cse_table" ,"cse_table","cse_table" ,"cse_table" ,"cse_table" ,"cse_table","cse_table"]
    
    

    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    


    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
        
        
        names = ["OverView","HOD Desk","People @ CSE","Laboratories","Departmental Activities","Student Achievements","Schemes/Syllabus","Photo Gallery","Research @ CSE"]
        identities = ["A","B","C","D","E","F","G","H","I"]
        
        

        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vcname = identities[indexPath.row]
        let viewController = storyboard?.instantiateViewController(withIdentifier: vcname)
        self.navigationController?.pushViewController(viewController!, animated: true)
        
    }
    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! TableViewCell1
        
        cell.myImage.image = UIImage(named: (imgs[indexPath.row] + ".png"))
        cell.myLabel.text = names[indexPath.row]
        
        return (cell)
        
    }
    
    override func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        //set inittial state
        cell.alpha = 0
        let transform = CATransform3DTranslate(CATransform3DIdentity, -250, 30, 0)
        
        cell.layer.transform = transform
        
        
        // animating to final state
        
        UIView.animate(withDuration: 1) {
            cell.alpha = 1
            cell.layer.transform = CATransform3DIdentity
        }
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return names.count
    }

}
