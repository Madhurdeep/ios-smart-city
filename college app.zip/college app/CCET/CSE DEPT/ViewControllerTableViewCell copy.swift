//
//  ViewControllerTableViewCell.swift
//  CCET
//
//  Created by Ravjot kaur on 24/08/17.
//  Copyright © 2017 MAC. All rights reserved.
//

import UIKit

class ViewControllerTableViewCell: UITableViewCell {
    
    @IBOutlet weak var lblDes: UILabel!

    @IBOutlet weak var lblTitle: UILabel!
    @IBOutlet weak var myImage: UIImageView!
    var isObserving = false;
    
    @IBOutlet weak var lblSpecial: UILabel!
    @IBOutlet weak var call: UIButton!
    @IBAction func callA(_ sender: Any) {
    }
    
    @IBOutlet weak var mail: UIButton!
    @IBAction func mailA(_ sender: Any) {
    }
    
    @IBOutlet weak var lblContact: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    
    
    
    class var expandedHeight: CGFloat { get { return 700 } }
    class var defaultHeight: CGFloat  { get { return 150  } }
    
    func checkHeight() {
        lblDes.isHidden = (frame.size.height < ViewControllerTableViewCell.expandedHeight)
        lblSpecial.isHidden = (frame.size.height < ViewControllerTableViewCell.expandedHeight)
        lblContact.isHidden = (frame.size.height < ViewControllerTableViewCell.expandedHeight)
    }
    
    func watchFrameChanges() {
        if !isObserving {
            addObserver(self, forKeyPath: "frame", options: [NSKeyValueObservingOptions.new, NSKeyValueObservingOptions.initial], context: nil)
            isObserving = true;
        }
    }
    
    func ignoreFrameChanges() {
        if isObserving {
            removeObserver(self, forKeyPath: "frame")
            isObserving = false;
        }
    }
    
    override func observeValue(forKeyPath keyPath: String?, of object: Any?, change: [NSKeyValueChangeKey : Any]?, context: UnsafeMutableRawPointer?) {
        if keyPath == "frame" {
            checkHeight()
        }
    }

    
    
}
