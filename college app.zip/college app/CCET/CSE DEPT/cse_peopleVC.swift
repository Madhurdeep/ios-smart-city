//
//  cse_peopleVC.swift
//  CCET
//
//  Created by MAC on 22/08/17.
//  Copyright © 2017 MAC. All rights reserved.
//

import UIKit

class cse_peopleVC: UIViewController , UITableViewDelegate, UITableViewDataSource {
var rows = 0
    
    @IBOutlet weak var MyTableView: UITableView!
    let teachers = ["Dr. Manpreet Singh Gujral - Professor","Dr. Sunil.K.Singh - Professor & Head","Dr. R.B. Patel - Professor","Dr. Varun Gupta - Associate Professor","Dr. Dheerendra Singh - Associate Professor","Er. Gulshan Goyal - Assistant Professor","Er. Sunita - Assistant Professor","Er. Amit Chhabra - Assistant Professor","Er. Ankit Gupta - Assistant Professor","Er. Sarabjeet Singh - Assistant Professor","Mr. Sudhakar Kumar - Assistant Professor","Er. Animesh Singh - Assistant Professor"]
    
    let qualification = ["Educational Qualification: BE, ME, Phd","Educational Qualification: B.E.(CSE), M.E.(CSE), PHD(CSE)","Educational Qualification: B.E.(CSE), M.E.(CSE), PHD(CSE), PDF(CSE)","Educational Qualification:  B.Tech.(CSE), M.E.(CSE), PHD.","Educational Qualification: B.E.(CSE), M.Tech.(CSE), PhD(CSE)","Educational Qualification: B.E.(CSE), M.Tech.(CSE), Pursuing Ph. D. in Computer Science & Engineering","Educational Qualification: B.E.(CSE), M.E.(CSE), Pursuing PHD(CSE)","Educational Qualification: B.E.(CSE), M.E.(CSE), Pursuing PHD(CSE)","Educational Qualification:  B.E.(CSE), M.Tech(CSE), Pursuing PHD(CSE)","Educational Qualification: B.E.(CSE), M.E.(CSE) ,Pursuing PHD","Educational Qualification:  B.Tech(CSE), M.Tech(CSE)","Educational Qualification: B.E.(CSE), M.E.(CSE) ,Pursuing PHD"]
    
    let special = ["Area of specialization: Computer Networks & Information Security","Area of specialization: Reconfigurable Computing,High Performance Computing, Embedded System, Linux","Area of specialization: Mobile & Distributed Computing","Area of specialization: Deep Learning, Big Data Analytics, Smart Grid, Software Engineering, Object-Orientation, ERP Systems, AMR Systems","Area of specialization: Cloud Computing, Web Engineering, S/W Engineering, Operating Systems, Data Structures & Programming, Database Systems, UNIX/LINUX Shell Programming, C, C++ Language","Area of specialization: Digital Image Processing, Theory of Computation, Compiler Design, Design and Analysis of Algorithms, Research Methodology, Discrete Structures, Statistical Models for Computer Science, Software Engineering , C, C++, MATLAB","Area of specialization: Design & Analysis of Algorithm, Data Structures","Area of specialization: Theory Of Computation, Compiler Design, Discrete Structure, Design , Analysis and Algorithm, Wireless Networks","Area of specialization: Artificial Intelligence, Web Intelligence, Web Analytics, Multi Criteria Decision Making, Information Retrieval","Area of specialization: High Performance Computing, Computer Graphics, C, C++, CUDA-C","Area of specialization: Human Computer Interaction, Software Engineering, Data Structures & Programming","Area of specialization: Software Engineering, Image Processing, Machine Learning, Human Computer Interaction"]
    
    let contact = ["Contact Address: Ms.Lalita Sharma, PA to Principal, Principal Office, First Floor(BLOCK-A), CCET, Chd (Degree Wing)","Contact Address: Room no. 415, CSE Department. CCET Degree Wing, Sector 26 Chandigarh 160019","Contact Address: Room No.-108 Deptt. Of Applied Science Block- A CCET(Degree Wing)","Contact Address: Room No.-413 Deptt. Of Computer Science & Engineering CCET(Degree Wing) Chandigarh","Contact Address: Room no. 414, CSE Department. CCET Degree Wing, Sector 26 Chandigarh 160019","Contact Address: ROOM NO.-425 Department of Computer Science and Engineering, CCET (Degree Wing), Sector-26 Chandigarh 160019","Contact Address: Room No.- 424 Department of Computer Science and Engineering, CCET (Degree Wing), Sector-26 Chandigarh 160019","Contact Address: Room No.- 424 Department of Computer Science and Engineering, CCET (Degree Wing), Sector-26 Chandigarh 160019","Contact Address: Room No.- 416, Department of Computer Science and Engineering, CCET (Degree Wing), Sector-26 Chandigarh 160019","Contact Address: ROOM NO.-416 Department of Computer Science and Engineering, CCET (Degree Wing), Sector-26 Chandigarh 160019","Contact Address: Room No-215, CL7 LAB, CSE Department. CCET Degree Wing, Sector 26 Chandigarh 160019","Contact Address: Room No 422, CSE Dept. CCET Degree Wing, Sector-26, Chandigarh"]
    var selectedIndexPath : IndexPath?
    
    
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // return (teachers.count)
        return rows
    }
    
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! ViewControllerTableViewCell
        cell.lblTitle.text = teachers[indexPath.row]
        cell.myImage.image = UIImage(named: (teachers[indexPath.row] + ".png"))
        cell.lblDes.text = qualification[indexPath.row]
        cell.lblSpecial.text = special[indexPath.row]
        cell.lblContact.text = contact[indexPath.row]
        
        
        
        return (cell)
    }

    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //MyTableView.dataSource = self
        //  MyTableView.delegate = self
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        insertRowsMode3()
    }
    
    
    
    
    
    func insertRowsMode3() {
        
        //adding logic to reset rows
        rows = 0
        //invoke the new insertRowMode3 function
        insertRowMode3(ind: 0)
    }
    
    //Changed insertRowMode3 into recursive to gain reusability
    //1. removed the second input of string
    //2. removed the completion handler
    //3. added recursive invokation
    func insertRowMode3(ind:Int) {
        let indPath = IndexPath(row: ind, section: 0)
        rows = ind + 1
        MyTableView.insertRows(at: [indPath], with: .right)
        
        //add condition here if ind == ary.count-1 return
        guard ind < teachers.count-1 else { return }
        DispatchQueue.main.asyncAfter(deadline: .now()+0.15) {
            //invoke the function itself
            self.insertRowMode3(ind: ind+1)
        }
    }
    
    
    
    func insertRowsMode2() {
        //clean the code for mode 2
        //using for loop
        //in this case the rows cannot be ary.count any more
        for i in 0..<teachers.count {
            insertRowMode2(ind: i, str: teachers[i])
        }
        
    }
    
    func insertRowMode2(ind:Int,str:String) {
        
        let indPath = IndexPath(row: ind, section: 0)
        //update number of rows
        rows = ind + 1
        MyTableView.insertRows(at: [indPath], with: .right)
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let previousIndexPath = selectedIndexPath
        if indexPath == selectedIndexPath {
            selectedIndexPath = nil
        } else {
            selectedIndexPath = indexPath
        }
        
        var indexPaths : Array<IndexPath> = []
        if let previous = previousIndexPath {
            indexPaths += [previous]
        }
        if let current = selectedIndexPath {
            indexPaths += [current]
        }
        if indexPaths.count > 0 {
            tableView.reloadRows(at: indexPaths, with: UITableViewRowAnimation.automatic)
        }
    }
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        
        cell.alpha = 0
        let transform = CATransform3DTranslate(CATransform3DIdentity, -250, 30, 0)
        
        cell.layer.transform = transform
        
        
        // animating to final state
        
        UIView.animate(withDuration: 1) {
            cell.alpha = 1
            cell.layer.transform = CATransform3DIdentity
        }
        (cell as! ViewControllerTableViewCell).watchFrameChanges()
    }
    
    func tableView(_ tableView: UITableView, didEndDisplaying cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        (cell as! ViewControllerTableViewCell).ignoreFrameChanges()
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        for cell in MyTableView.visibleCells as! [ViewControllerTableViewCell] {
            cell.ignoreFrameChanges()
        }
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        if indexPath == selectedIndexPath {
            return ViewControllerTableViewCell.expandedHeight
        } else {
            return ViewControllerTableViewCell.defaultHeight
        }
    }
    
    
}

