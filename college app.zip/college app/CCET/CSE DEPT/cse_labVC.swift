//
//  cse_labVC.swift
//  CCET
//
//  Created by MAC on 22/08/17.
//  Copyright © 2017 MAC. All rights reserved.
//

import UIKit

class cse_labVC: UIViewController {

    @IBOutlet weak var TEXT_LBL: UILabel!
    var imgArray = [UIImage]()
   
    @IBOutlet weak var mainSView: UIScrollView!
    
    @IBAction func back(_ sender: Any) {
   
    }
    @IBAction func next(_ sender: Any) {
  
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        TEXT_LBL.text = "At CSE Department, students are challenged by a flexible, thought-provoking curriculum and learn from faculty members who are experts in their areas.\nTo support the learning and practices in above technological area, Department of CSE have well equipped computer center, project lab and oracle sponsored lab that have various Software Packages relevant to the Development of Minor and Major Projects undertaken during the Coursework. All the state of Art Facilities, Resources and Guidelines are provided to the students as per their requirement."
        
        mainSView.frame = view.frame
        
        imgArray = [#imageLiteral(resourceName: "Screen Shot 2017-08-24 at 12.11.58 AM"),#imageLiteral(resourceName: "Screen Shot 2017-08-24 at 12.11.41 AM"),#imageLiteral(resourceName: "Screen Shot 2017-08-24 at 12.11.27 AM"),#imageLiteral(resourceName: "Screen Shot 2017-08-24 at 12.11.52 AM"),#imageLiteral(resourceName: "Screen Shot 2017-08-24 at 12.11.33 AM")]
        for i in 0..<imgArray.count{
         let imageView = UIImageView()
            imageView.image = imgArray[i]
            imageView.contentMode = .scaleAspectFit
            let xPos = self.view.frame.width * CGFloat(i)
            imageView.frame = CGRect(x: xPos, y: -200, width: self.mainSView.frame.width,height: self.mainSView.frame.height)
            
            mainSView.contentSize.width = mainSView.frame.width * CGFloat(i+1)
            mainSView.addSubview(imageView)
        }
        

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
