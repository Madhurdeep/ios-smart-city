//
//  cse_overviewVC.swift
//  CCET
//
//  Created by MAC on 22/08/17.
//  Copyright © 2017 MAC. All rights reserved.
//

import UIKit

class cse_overviewVC: UIViewController
{
    @IBOutlet weak var star1: UIImageView!
    @IBOutlet weak var star2: UIImageView!
    @IBOutlet weak var star3: UIImageView!
    @IBOutlet weak var star4: UIImageView!
    @IBOutlet weak var star5: UIImageView!
    @IBOutlet weak var overview_outcomings: UILabel!
    var key = ""
    var key1 = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        getkey()
        
        if(key == "0")
        {
          star1.image = UIImage(named:"star1")!
          star2.image = UIImage(named:"star1")!
          star3.image = UIImage(named:"star1")!
          star4.image = UIImage(named:"star1")!
            
            hotel_img.image = UIImage(named:"jwmarriot")!
            
        overview_outcomings.text = "Located in the heart of Chandigarh, this luxury hotel is within 2 miles (3 km) of Bird Sanctuary, Sector 17 and CII Convention Centre. Zakir Rose Garden and Government Museum and Art Gallery are also within 3 miles (5 km)."
        }
            else if(key == "1")
        {
            star1.image = UIImage(named:"star1")!
            star2.image = UIImage(named:"star1")!
            star3.image = UIImage(named:"star1")!
            
            hotel_img.image = UIImage(named:"aroma")!
            
            overview_outcomings.text = "Hotel Aroma founded in 1953, is as old or as young as Chandigarh, The City beautiful. Acting as a Gateway to the city, Aroma has provided Chandigarh a number of “FIRSTS” : the first Airlines Office, the first taxi service, the first Courier Company, the first Florist to name a few. Today, Aroma is synonymous with innovative and caring hospitality, its hallmark being the family and corporate client segments."
        }
        else
        {
            overview_outcomings.text = "not found"
        }
        // Do any additional setup after loading the view.
    }

    @IBOutlet weak var hotel_img: UIImageView!
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func getkey()
    {
        
        let defaults = UserDefaults.standard
        let token = defaults.string(forKey: "Key0")
        self.key = token!
       
    }
    
    @IBAction func location(_ sender: Any){
        key1 = "4"
        set()
    }
    @IBAction func cab(_ sender: Any) {
        key1 = "3"
        set()
    }
    
    @IBAction func user_review(_ sender: Any) {
        key1 = "1"
        set()
    }
    @IBAction func weblink(_ sender: Any) {
        key1 = "2"
        set()
    }
    @IBAction func call(_ sender: Any) {
        key1 = "5"
        set()
    }
    
    func set()
    {
        let defaults = UserDefaults.standard
        defaults.set(self.key1, forKey: "Key1")
        defaults.synchronize()
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
