//
//  T_PVC.swift
//  CCET
//
//  Created by MAC on 01/09/17.
//  Copyright © 2017 MAC. All rights reserved.
//

import UIKit

class T_PVC: UIViewController , UITableViewDelegate ,UITableViewDataSource{
    
    
    
    @IBOutlet weak var TV: UITableView!
    
    
    var names = [String]()
    var identities = [String]()
    
    let imgs = [ "Dr. Manpreet Singh Gujral - Professor"]
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        names = ["JW Marriot"]
        identities = ["AA"]
        
        TV.dataSource = self
        TV.delegate = self
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
    /*  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
     
     let vcname = identities[indexPath.row]
     let viewController = storyboard?.instantiateViewController(withIdentifier: vcname)
     self.navigationController?.pushViewController(viewController!, animated: true)
     
     }*/
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = TV.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as! TableViewCell
        
        cell.myImage.image = UIImage(named: (imgs[indexPath.row] + ".JPG"))
        cell.myLabel.text = names[indexPath.row]
        
        return (cell)
        
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return names.count
    }
    
    
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        //set inittial state
        cell.alpha = 0
        let transform = CATransform3DTranslate(CATransform3DIdentity, -250, 30, 0)
        
        cell.layer.transform = transform
        
        
        // animating to final state
        
        UIView.animate(withDuration: 1) {
            cell.alpha = 1
            cell.layer.transform = CATransform3DIdentity
        }
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vcname = identities[indexPath.row]
        let viewcontroller = storyboard?.instantiateViewController(withIdentifier: vcname)
        self.navigationController?.pushViewController(viewcontroller!, animated: true)
    }
    
    
    
    
    
}

