//
//  hotels.swift
//  CCET
//
//  Created by Ravjot kaur on 18/01/18.
//  Copyright © 2018 MAC. All rights reserved.
//

import UIKit

class hotels: UIViewController ,UITableViewDelegate,UITableViewDataSource{
    var selectedIndexPath : IndexPath?
    
    @IBOutlet weak var MyTableView: UITableView!
    var key = ""
    
    var names = [String]()
    var identities = [String]()
    
    let imgs = [ "HOTEELS" ,"HOTEELS" ,"HOTEELS" ,"HOTEELS","HOTEELS" ,"HOTEELS" ,"HOTEELS" ,"HOTEELS","HOTEELS"]
    
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    func set()
    {
        let defaults = UserDefaults.standard
        defaults.set(self.key, forKey: "Key0")
        defaults.synchronize()
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        names = ["JW Marriot","Aroma","Sunbeam","Lalit","Taj","Park Plaza","Mount View","Western Court","Shivalik View"]
        identities = ["A","A","A","A","A","A","A","A","A"]
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false
        
        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Table view data source
    
     func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vcname = identities[indexPath.row]
        let viewController = storyboard?.instantiateViewController(withIdentifier: vcname)
        self.navigationController?.pushViewController(viewController!, animated: true)
        key = String(indexPath.row)
        set()
        
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
         let cell = tableView.dequeueReusableCell(withIdentifier: "hotels", for: indexPath) as! TableViewCell2
        
        cell.imgg.image = UIImage(named: (imgs[indexPath.row] + ".png"))
        cell.textt.text = names[indexPath.row]
        
        return (cell)
    }
    

        
    
        
        


    
  func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        //set inittial state
        cell.alpha = 0
        let transform = CATransform3DTranslate(CATransform3DIdentity, -250, 30, 0)
        
        cell.layer.transform = transform
        
        
        // animating to final state
        
        UIView.animate(withDuration: 1) {
            cell.alpha = 1
            cell.layer.transform = CATransform3DIdentity
        }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return names.count
    }


}
